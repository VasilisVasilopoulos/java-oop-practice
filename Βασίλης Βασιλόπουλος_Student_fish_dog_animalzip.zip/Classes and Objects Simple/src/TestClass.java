
public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student panos = new Student("panos",697737373,434434,"panos@iek.gr");
		Student nikos = new Student("nikos",432344,5435,"nikos@iek.gr");
		Student kostas = new Student("kostas",4324,-42342,"kostas@eff.gr");
		
		Student kiki = new Student("kiki",786876);
		Student lili = new Student();
		
		
		panos.print();
		nikos.print();
		kostas.print();
		
		panos.setEmail("panos@iefjidsf.gr");
		panos.print();
		
		panos.setAmka(-7654);
		nikos.setAmka(-43434);
		System.out.println(panos.getAmka());
		
		
		
		
	}

}
