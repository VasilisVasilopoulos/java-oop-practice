import java.util.Scanner;

public class Student {

	Scanner input = new Scanner (System.in);
	
	private String name;
	private int mobile;
	private int amka;
	private String email;
	
	
	public Student (String name, int mobile, int amka, String email) {
		
		this.email = email;
		this.mobile = mobile;
		setAmka(amka);
		this.name = name;
		
	}
	
	public Student (String name, int mobile) {

		this.mobile=mobile;
		this.name = name;
		
	}
	
	public Student() {
		
	}
	
	
	
	
	
	
	public String getName() {
		return name;
	}
	
	public int getMobile() {
		return mobile;
	}
	
	public String getEmail() {
		return email;
	}
	
	public int getAmka() {
		return amka;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setAmka(int amka) {
		
		while (amka<0) {
			System.out.println("lathos dose thetiko airthmo");
			amka= input.nextInt();
			
		}
		this.amka =amka;
	}
	
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	
	
	public void print () {
		System.out.println( "name " +name + " amka " + amka +
							" mobile " +mobile + " email " +email);
	}
	
	
	

}
