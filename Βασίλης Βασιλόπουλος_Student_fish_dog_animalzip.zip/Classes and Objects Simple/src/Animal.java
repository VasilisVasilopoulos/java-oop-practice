public class Animal {

	private String color;
	private String breed;
	
	public Animal (String color, String breed) {
	
		this.color =color;
		this.breed = breed;
	}
	
	public String getBreed() {
		return " kjfiudshfushdj" + breed;
	}
	
	public String getColor() {
		return color + "RGB";
	}
	
	public void setBreed(String breed) {
		this.breed = breed;
	}
	
	public void setColor(String color) {
		this.color=color;
	}
	
	public String toString() {
		return "Breed = " + getBreed() + "Color = " + getColor();
	}
	
	
}
