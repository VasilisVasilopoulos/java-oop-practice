import java.util.Scanner;

public class Dog extends Animal{

	Scanner input = new Scanner(System.in);
	
	private String name;
	private String bark_noise;
	private int weight;
	
	
	public Dog (String color,String name, String breed, String bark_noise, int weight) {
		super(color,breed);
		this.name=name;
		this.bark_noise=bark_noise;
		setWeight(weight);
	}
	
	public Dog (String name, String breed, String color) {
		super(breed,color);
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	
	public String getBarkNoise() {
		return bark_noise;
	}
	
	public void setBarknoise(String bark_noise)
	{
		this.bark_noise=bark_noise;
	}
	
	public int getWeight() {
		return weight;
	}
	
	public void setWeight(int weight) {
		
		while(weight<0) {
			System.out.println("dose thetiko varos");
			weight=input.nextInt();
		}
		
		this.weight=weight;
		
	}
	
	public String toString() {
		return  super.toString() + " name =  " +getName() + " Bark noise=  " +getBarkNoise()
				+ " weight =  " +getWeight();
	}
	
	
}

