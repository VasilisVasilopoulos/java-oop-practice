
public class TestFish {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Fish nemo = new Fish ("xrisopsaro","kitrino","gliko nero");
		
		Fish mini = new Fish ("pestrofa","kokkini");
		
		
		nemo.print();
		mini.print();
		
		mini.setWater_Type("almiro");
		
		System.out.println(mini.getWater_Type());
		
		
	}

}
