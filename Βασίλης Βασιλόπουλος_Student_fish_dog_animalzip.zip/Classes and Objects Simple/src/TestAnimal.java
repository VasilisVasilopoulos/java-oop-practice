
public class TestAnimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Dog max = new Dog ("leuko","boxer","max","waf-waf",45);
		Dog mini = new Dog ("jack russel"," kafe","mini");
		
		Fish topsarimou = new Fish("xrisopaso","portokali","almiro");
		
		mini.setWeight(89);
		
		System.out.println(max.toString());

		System.out.println(mini.toString());

		System.out.println(topsarimou.toString());
		
	}

}
