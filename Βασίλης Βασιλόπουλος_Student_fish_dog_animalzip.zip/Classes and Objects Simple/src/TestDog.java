
public class TestDog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Dog max = new Dog ("max","jack-russel","woof-woof",89);
		Dog luna = new Dog ("luna","boxer");
		Dog sak = new Dog ("sak","pitbull","waf-waf",-89);
		
		
		luna.setBarknoise("woof woof");
		luna.setWeight(56);
		
		max.print();
		luna.print();
		sak.print();
		
	}

}
