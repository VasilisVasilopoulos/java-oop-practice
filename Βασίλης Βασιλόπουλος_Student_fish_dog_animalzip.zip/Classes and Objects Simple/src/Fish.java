
public class Fish extends Animal {

	
	private String water_type;
	
	
	public Fish (String breed, String color, String water_type ) {
		super(breed,color);
		this.water_type = water_type;
		
	}
		
	public String getWater_Type() {
		return water_type;
	}
	
	
	public void setWater_Type(String water_type) {
		this.water_type = water_type;
		
	}
	
	public String toString() {
		return super.toString() + " water_type = " + getWater_Type();
	}
	
	
}
